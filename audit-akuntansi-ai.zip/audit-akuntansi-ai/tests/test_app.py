from streamlit.testing.v1 import AppTest

def test_app_jalan_tanpa_error():
    at = AppTest.from_file("../app.py", default_timeout=60).run()
    assert not at.exception, at.exception
    assert len(at.metric) >= 4
    assert at.tabs  # 5 tab tampil

def test_chat_tanpa_key_tidak_crash():
    at = AppTest.from_file("../app.py", default_timeout=60).run()
    at.chat_input[0].set_value("Halo").run()
    assert not at.exception
